# gogs
gogs szerver telepítése
